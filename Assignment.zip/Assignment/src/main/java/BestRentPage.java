import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class BestRentPage {

    private WebDriver driver;

    By startingPriceCommunityPageTable = By.xpath("//table[@id='listings']//tbody/tr[@class='active'][1]/td[4]");


    public BestRentPage() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    public void launchBestRentPage() {
        driver.get("https://bestrentnj.com/all-nj-apartments/");
        waitForPageToLoad();
    }

    public void waitForPageToLoad() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            ExpectedCondition<Boolean> pageLoadCondition = webDriver ->
                    ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete");

            wait.until(pageLoadCondition);
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void waitForElementToBePresent(By locator) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            scrollToElement(element);
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void waitForElementToBeVisible(By locator) {
        try {
            waitForElementToBePresent(locator);
            WebDriverWait wait = new WebDriverWait(driver, 30);
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            scrollToElement(element);
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void waitForElementToBeClickable(By locator) {
        try {
            waitForElementToBeVisible(locator);
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.elementToBeClickable(locator));
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }


    public void safeClick(By locator) {
        try {
            waitForElementToBeClickable(locator);
            driver.findElement(locator).click();
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void safeActionsClick(By locator) {
        try {
            waitForElementToBeVisible(locator);
            waitForElementToBeClickable(locator);
            javaScriptClick(driver.findElement(locator));
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void javaScriptClick(WebElement element) {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", element);
    }

    // Scroll to a specific element
    public void scrollToElement(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public String safeGetText(By locator) {
        String text = null;
        try {
            waitForElementToBeVisible(locator);
            text = driver.findElement(locator).getText();
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
        return text;
    }


    public void verifyThePriceOnCommunityPage() {
        try {
            List<WebElement> links = driver.findElements(By.xpath("//ul[@class='grid-dynamic']//li//a[@href]"));
            for (int i = 1; i <= links.size(); i++) {
                By propertylinks = By.xpath("(//ul[@class='grid-dynamic']//li//a[@href])[" + i + "]");
                By startingPriceBestRentPage = By.xpath("(//ul[@class='grid-dynamic']//li//a//p[@class='beds'])[" + i + "]");
                String[] typeOfPropertiesOnBestRentPage = safeGetText(startingPriceBestRentPage).split("\\n");
                safeClick(propertylinks);
                for (int k = 0; k < typeOfPropertiesOnBestRentPage.length; k++) {
                    String[] numberOfRoomsAndPrice = typeOfPropertiesOnBestRentPage[k].split("from ");
                    waitForPageToLoad();
                    verifyThePriceForEachProperty(numberOfRoomsAndPrice, typeOfPropertiesOnBestRentPage, i);
                }
                driver.navigate().back();
            }
        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public void verifyThePriceForEachProperty(String[] numberOfRoomsAndPrice, String[] typeOfPropertiesOnBestRentPage, int propertyNum) {
        try {
            for (int j = 0; j < numberOfRoomsAndPrice.length; j++) {
                if (typeOfPropertiesOnBestRentPage.length > 1)
                    safeActionsClick(By.xpath("//ul[@id='tableList']/li[contains(text(),'" + numberOfRoomsAndPrice[j].trim() + "')]"));
                String startingPriceonBRPageCommunity = "from " + numberOfRoomsAndPrice[++j].trim();
                String startingPriceCommunityPage = safeGetText(startingPriceCommunityPageTable).trim();
                if (startingPriceonBRPageCommunity.equalsIgnoreCase(startingPriceCommunityPage)) {
                    System.out.println("Price Matching for property: " + propertyNum + " for " + numberOfRoomsAndPrice[j - 1]);
                } else {
                    System.out.println("Price not Matching for property: " + propertyNum + " for " + numberOfRoomsAndPrice[j - 1]);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            closeBrowser();
        }
    }

    public static void main(String[] args) {
        BestRentPage bestRentPage = new BestRentPage();
        bestRentPage.launchBestRentPage();
        bestRentPage.verifyThePriceOnCommunityPage();
        bestRentPage.closeBrowser();
    }

    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}
